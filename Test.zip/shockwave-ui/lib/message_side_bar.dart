import 'package:flutter/material.dart';

class MessageSidebar extends StatefulWidget {
  const MessageSidebar({super.key});

  @override
  State<MessageSidebar> createState() => _MessageSidebarState();
}

class _MessageSidebarState extends State<MessageSidebar> {
  int? _replyingTo;
  final TextEditingController _replyController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _messages.addAll([
      {'text': 'Hey, we’re tracking live here', 'time': now.subtract(const Duration(minutes: 5))},
      {'text': 'Map updated with the latest route changes', 'time': now.subtract(const Duration(minutes: 15))},
      {'text': 'Reminder: Check the pinned location for more details', 'time': now.subtract(const Duration(hours: 2))},
      {'text': 'Requesting ground support at the northern ridge.', 'time': now.subtract(const Duration(hours: 5))},
      {'text': 'Evac point marked—rendezvous at 1400 hours.', 'time': now.subtract(const Duration(days: 1))},
      {'text': 'Hostiles detected east of checkpoint Bravo.', 'time': now.subtract(const Duration(minutes: 45))},
      {'text': 'Awaiting orders for next sweep.', 'time': now.subtract(const Duration(hours: 3))},
      {'text': 'Drone surveillance active over sector 19.', 'time': now.subtract(const Duration(hours: 6))},
    ]);
    _messages.sort((a, b) => (b['time'] as DateTime).compareTo(a['time'] as DateTime));
  }

  String timeAgo(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
    if (diff.inHours < 24) return '${diff.inHours} hr ago';
    return '${diff.inDays} day${diff.inDays > 1 ? 's' : ''} ago';
  }

  void _showReply(int index) {
    setState(() {
      _replyingTo = index;
      _replyController.clear();
    });
  }

  void _sendReply(int index) {
    if (_replyController.text.trim().isEmpty) return;
    setState(() {
      _messages.insert(0, {
        'text': _replyController.text.trim(),
        'time': DateTime.now(),
        'replyTo': null,
        'replySub': _replyController.text.trim(),
      });
      _replyingTo = null;
      _replyController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(left: BorderSide(color: theme.colorScheme.primary.withOpacity(0.3))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ShaderMask(
            shaderCallback: (Rect bounds) {
              return LinearGradient(
                colors: [theme.colorScheme.primary, theme.colorScheme.secondary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(bounds);
            },
            child: Text(
              'Messages',
              style: TextStyle(
                color: theme.colorScheme.onSurface,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.separated(
              itemCount: _messages.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final text = msg['text'] as String;
                final time = msg['time'] as DateTime;
                final isCritical = text.toLowerCase().contains('hostiles') ||
                    text.toLowerCase().contains('backup') ||
                    text.toLowerCase().contains('awaiting orders') ||
                    text.toLowerCase().contains('evac') ||
                    text.toLowerCase().contains('detected');
                final preview = text.length > 40 ? '${text.substring(0, 37)}...' : text;
                final sentAgo = timeAgo(time);
                final isReplying = _replyingTo == index;
                return GestureDetector(
                  onTap: () => _showReply(index),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.background,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: theme.colorScheme.primary.withOpacity(0.2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            if (isCritical) ...[
                              Icon(Icons.warning_amber_rounded, color: theme.colorScheme.error, size: 20),
                              const SizedBox(width: 8),
                            ],
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    preview,
                                    style: TextStyle(color: theme.textTheme.bodyMedium?.color, fontSize: 14),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    sentAgo,
                                    style: TextStyle(color: theme.textTheme.bodyMedium?.color, fontSize: 12),
                                  ),
                                  if (msg['replySub'] != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4.0),
                                      child: Text(
                                        '↳ ${msg['replySub']}',
                                        style: TextStyle(color: theme.colorScheme.primary, fontSize: 12, fontStyle: FontStyle.italic),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            Icon(Icons.call, color: theme.colorScheme.primary, size: 18),
                            const SizedBox(width: 10),
                            Icon(Icons.arrow_forward_ios, color: theme.colorScheme.primary, size: 16),
                          ],
                        ),
                        if (isReplying) ...[
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: TextField(
                                  controller: _replyController,
                                  decoration: InputDecoration(
                                    hintText: 'Type your reply...',
                                    filled: true,
                                    fillColor: theme.colorScheme.surface,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide: BorderSide.none,
                                    ),
                                  ),
                                  style: TextStyle(color: theme.colorScheme.onSurface),
                                ),
                              ),
                              const SizedBox(width: 8),
                              ElevatedButton(
                                onPressed: () => _sendReply(index),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: theme.colorScheme.primary,
                                  foregroundColor: theme.colorScheme.onPrimary,
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                ),
                                child: Text('Send', style: TextStyle(color: theme.colorScheme.onPrimary)),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
