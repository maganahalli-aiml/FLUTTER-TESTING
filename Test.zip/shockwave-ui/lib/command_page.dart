import 'package:flutter/material.dart';

class CommandPage extends StatelessWidget {
  const CommandPage({super.key});

  @override
  Widget build(BuildContext context) {

    final theme = Theme.of(context);
    return Center(
      child: Text('Command Page', style: theme.textTheme.bodyLarge),
    );
  }
}
