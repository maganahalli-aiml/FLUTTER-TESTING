import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class MyMapPage extends StatelessWidget {
  const MyMapPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Geospatial Awareness')),
      body: FlutterMap(
        options: MapOptions(
          center: LatLng(38.24, 127.089),
          // center: LatLng(38.8048, -77.0469),
          zoom: 13.0,
        ),
        children: [
          TileLayer(
            urlTemplate:
                'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.myapp',
          ),
          MarkerLayer(
            markers: [
              // Korea
              Marker(
                width: 80.0,
                height: 80.0,
                point: LatLng(38.24, 127.089),
                child: Icon(
                  Icons.location_pin,
                  color: theme.colorScheme.primary,
                  size: 40,
                ),
              ),
              // Alexandria
              Marker(
                width: 80.0,
                height: 80.0,
                point: LatLng(38.8048, -77.0469),
                child: Icon(
                  Icons.location_pin,
                  color: theme.colorScheme.primary,
                  size: 40,
                ),
              ),
              // Division
              Marker(
                width: 80.0,
                height: 80.0,
                point: LatLng(35.3166909, 127.1657768),
                child: Icon(
                  Icons.location_pin,
                  color: theme.colorScheme.primary,
                  size: 40,
                ),
              ),
              // Divarty
              Marker(
                width: 80.0,
                height: 80.0,
                point: LatLng(35.5117752, 127.7699012),
                child: Icon(
                  Icons.location_pin,
                  color: theme.colorScheme.primary,
                  size: 40,
                ),
              ),
              //  Rocket Plooton
              Marker(
                width: 80.0,
                height: 80.0,
                point: LatLng(35.5496125, 128.3968390),
                child: Icon(
                  Icons.location_pin,
                  color: theme.colorScheme.primary,
                  size: 40,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
