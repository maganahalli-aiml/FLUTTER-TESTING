import 'package:flutter/material.dart';

class ShockwaveTitle extends StatelessWidget {
  final double fontSize;
  const ShockwaveTitle({super.key, this.fontSize = 28});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ShaderMask(
      shaderCallback: (Rect bounds) {
        return LinearGradient(
          colors: [
            theme.colorScheme.primary,
            theme.colorScheme.secondary,
            theme.colorScheme.onSurface,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(bounds);
      },
      child: Text(
        'NGC2',
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.bold,
          letterSpacing: 2,
          color: theme.colorScheme.onSurface,
          shadows: [
            Shadow(blurRadius: 8, color: theme.colorScheme.primary.withOpacity(0.5), offset: const Offset(0, 2)),
            Shadow(blurRadius: 16, color: theme.colorScheme.secondary.withOpacity(0.3), offset: const Offset(0, 4)),
          ],
        ),
      ),
    );
  }
}
