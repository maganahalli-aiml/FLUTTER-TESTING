import 'package:flutter/material.dart';
import 'package:shockwave/screens/war_fighting_dashboard.dart';
import 'map_page.dart';
import 'comms_page.dart';
import 'fires_page.dart';
import 'command_page.dart';
import 'settings_page.dart';
import 'hamburger_nav.dart';
import 'packageManager.dart'; // Importing PackageManagerPage
import 'login_page.dart';
import 'shockwave_title.dart';
import 'node_connection_page.dart'; // Importing NodeConnectionPage
import 'profile.dart';
import 'themes/dark_theme.dart';
import 'themes/theme_manager.dart';
import "themes/light_theme.dart";
void main() async {

  WidgetsFlutterBinding.ensureInitialized(); // Ensure Flutter is initialized
  await ThemeManager.loadTheme(); // Load saved theme preference
  runApp(GeoCommandApp());
  
}


class GeoCommandApp extends StatelessWidget {
  const GeoCommandApp({super.key});


  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, themeMode, child) {
        return MaterialApp(
          theme: shockwaveLightTheme,
          darkTheme: shockwaveDarkTheme,
          themeMode: themeMode,
          debugShowCheckedModeBanner: false,
          home: const AuthGate(), // Use AuthGate as the entry point
        );
      },
    );
   
  
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool _authenticated = false;

  void _onLoginSuccess() {
    setState(() {
      _authenticated = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_authenticated) {
      return const MainApp();
    } else {
      return LoginPage(onLoginSuccess: _onLoginSuccess);
    }
  }
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int _currentIndex = 0;
  bool _showBottomNav = false;

  final List<Widget> _pages = [
    WarFightingDashboard(),
    MapPage(),
    CommsPage(),
    CommandPage(),
    PackageManagerPage(),
    NodeConnectionPage(), // New tab
    SettingsPage(),
    ProfilePage(),
  ];

  void _onNavTapped(int index) {
    if (index == 8) {
      setState(() {
        _showBottomNav = false;
      });
    } else {
      setState(() {
        _currentIndex = index;
      });
    }
  }
  

  void _navigateTo(int index) {
    setState(() => _currentIndex = index);
    Navigator.of(context).pop(); // close drawer
  }

  @override
  Widget build(BuildContext context) {
  
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: theme.appBarTheme.backgroundColor,
        title: const ShockwaveTitle(fontSize: 26),
        centerTitle: true,
        leading: Builder(
          builder: (context) => ShaderMask(
            shaderCallback: (Rect bounds) {
              return LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.secondary,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ).createShader(bounds);
            },
            child: IconButton(
              icon: Icon(Icons.menu, color: theme.iconTheme.color),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
        // Removed actions
      ),
      drawer: HamburgerNav(
        currentIndex: _currentIndex,
        onTapTab: (index) {
          setState(() => _currentIndex = index);
          Navigator.of(context).pop();
        },
      ),
      body: 
      Stack(
        children: [
          SafeArea(child: _pages[_currentIndex]),
          if (!_showBottomNav)
            Positioned(
              bottom: MediaQuery.of(context).size.height < 600 ? 16 : 24,
              right: MediaQuery.of(context).size.width < 600 ? 16 : 32,
              child: Material(
                color: Colors.transparent,
                child: Tooltip(
                  message: 'Show Quick Bar',
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      setState(() {
                        _showBottomNav = true;
                      });
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.menu_open, color: theme.iconTheme.color, size: 26),
                    ),
                  ),
                ),
              ),
            ),
        ],
        
      ),
      bottomNavigationBar: _showBottomNav
          ? BottomNavigationBar(
              backgroundColor: theme.bottomNavigationBarTheme.backgroundColor,
              selectedItemColor: theme.bottomNavigationBarTheme.selectedItemColor,
              unselectedItemColor: theme.bottomNavigationBarTheme.unselectedItemColor?.withOpacity(0.54),
              type: BottomNavigationBarType.fixed,
              currentIndex: _currentIndex,
              onTap: _onNavTapped,
              items: [
                BottomNavigationBarItem(icon: Icon(Icons.apps), label: 'Apps'),
                BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Map'),
                BottomNavigationBarItem(icon: Icon(Icons.chat_bubble), label: 'Comms'),
                BottomNavigationBarItem(icon: Icon(Icons.group), label: 'Command'),
                BottomNavigationBarItem(icon: Icon(Icons.extension), label: 'Packages'),
                BottomNavigationBarItem(icon: Icon(Icons.hub), label: 'Node Connection'),
                BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
                BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
                BottomNavigationBarItem(icon: Icon(Icons.visibility_off, color: theme.iconTheme.color),label: 'Hide',),
              ],
            )
          : null,
    );
  }
}
