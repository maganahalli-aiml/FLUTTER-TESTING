import 'package:flutter/material.dart';

final ThemeData shockwaveLightTheme = ThemeData.dark().copyWith(
  scaffoldBackgroundColor: const Color(0xFFF0F0F0),
  primaryColor: const Color(0xFF27355D),
  brightness: Brightness.light,
  colorScheme: ColorScheme(
    brightness: Brightness.light,
    primary: const Color(0xFF27355D),
    secondary: const Color(0xFF50556D),
    background: const Color(0xFFF0F0F0),
    surface: const Color(0xFFE1E1E1),
    onPrimary: Colors.white,
    onSecondary: Colors.white,
    onBackground: Colors.black,
    onSurface: Colors.black,
    error: Colors.redAccent,
    onError: Colors.white,
    tertiary: const Color(0xFFE7E7E7)

    // Add more if needed
  ),
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Color(0xFF000000), fontSize: 20),
    bodyMedium: TextStyle(color: Color(0xFF323D61)),
    titleLarge: TextStyle(color: Color(0xFF27355D)),
    titleMedium: TextStyle(color: Color(0xFF50556D)),
    labelLarge: TextStyle(color: Color(0xFFFFFFFF)),
  ),
  iconTheme: const IconThemeData(color: Color(0xFF3C4565)),
  listTileTheme: ListTileThemeData(
    iconColor: Color(0xFF3C4565),
    textColor: Color(0xFF000000),
    selectedTileColor: Color(0xFFB6B6B6).withOpacity(0.4),
    style: ListTileStyle.drawer,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: Color(0xFFF0F0F0),
    iconTheme: IconThemeData(color: Color(0xFF000000)),
  ),

  bottomNavigationBarTheme: BottomNavigationBarThemeData(
    backgroundColor: Color(0xFFFFFFFF),
    selectedItemColor: Color(0xFF27355D),
    unselectedItemColor: Color(0xFF50556D),
    selectedIconTheme: IconThemeData(color: Color(0xFF27355D)),
    unselectedIconTheme: IconThemeData(color: Color(0xFF50556D)),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: Color(0xFF27355D),
      foregroundColor: Color(0xFFFFFFFF),
    ),
  ),

  useMaterial3: true,
);
