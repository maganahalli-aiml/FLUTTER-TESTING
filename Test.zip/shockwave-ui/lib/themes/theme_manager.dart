import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier<ThemeMode>(
  ThemeMode.dark,
);

class ThemeManager {
  static const String _key = "theme_mode";

  static Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final savedTheme = prefs.getString(_key) ?? 'dark';
    themeNotifier.value = savedTheme == 'light'
        ? ThemeMode.light
        : ThemeMode.dark;
  }

  static Future<void> toggleTheme(bool isDark) async {
    final prefs = await SharedPreferences.getInstance();
    final newTheme = isDark ? 'dark' : 'light';
    await prefs.setString(_key, newTheme);

    themeNotifier.value = isDark ? ThemeMode.dark : ThemeMode.light;
  }
}
