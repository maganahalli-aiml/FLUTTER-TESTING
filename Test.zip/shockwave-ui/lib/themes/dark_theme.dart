import 'package:flutter/material.dart';

final ThemeData shockwaveDarkTheme = ThemeData.dark().copyWith(
  scaffoldBackgroundColor: const Color(0xFF1E1E2E),
  primaryColor: const Color(0xFFFFF700),
  brightness: Brightness.dark,
  colorScheme: ColorScheme(
    brightness: Brightness.dark,
    primary: const Color(0xFFFFF700),
    secondary: const Color(0xFFFFE066),
    background: const Color(0xFF1E1E2E),
    surface: const Color(0xFF2A2A3D),
    onPrimary: Colors.black,
    onSecondary: Colors.black,
    onBackground: Colors.white,
    onSurface: Colors.white,
    error: Colors.redAccent,
    onError: Colors.white,
    tertiary: const Color(0xFF2E2E3E)

    // Add more if needed
  ),
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Colors.white, fontSize: 20),
    bodyMedium: TextStyle(color: Colors.white70),
    titleLarge: TextStyle(color: Color(0xFFFFF700)),
    titleMedium: TextStyle(color: Color(0xFFFFE066)),
    labelLarge: TextStyle(color: Colors.black),
  ),
  iconTheme: const IconThemeData(color: Colors.yellowAccent),
  listTileTheme: ListTileThemeData(
    iconColor: Colors.yellowAccent,
    textColor: Colors.white,
    selectedTileColor: const Color(0xFFFFF700).withOpacity(0.1),
    style: ListTileStyle.drawer,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: const Color(0xFF1E1E2E),
    iconTheme: const IconThemeData(color: Colors.white),
  ),
  bottomNavigationBarTheme: BottomNavigationBarThemeData(
    backgroundColor: const Color(0xFF2A2A3D),
    selectedItemColor: const Color(0xFFFFF700),
    unselectedItemColor: Colors.white54,
    selectedIconTheme: const IconThemeData(color: Color(0xFFFFF700)),
    unselectedIconTheme: const IconThemeData(color: Colors.white54),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFFFFF700), // Primary color for buttons
      foregroundColor: Colors.white, // Text color on buttons
    ),
  ),
  useMaterial3: true,
);
