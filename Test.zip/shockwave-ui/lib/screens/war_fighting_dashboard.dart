import 'package:flutter/material.dart';
import '../data/war_fighting_data.dart';
import '../widgets/war_fighting_function_card.dart';

class WarFightingDashboard extends StatelessWidget {
  const WarFightingDashboard({super.key});

  int _calculateCrossAxisCount(double screenWidth) {
    int crossAxisCount = 1;
    if (screenWidth > 1200) {
      crossAxisCount = 4;
    } else if (screenWidth > 900) {
      crossAxisCount = 3;
    } else if (screenWidth > 600) {
      crossAxisCount = 2;
    }
    return crossAxisCount;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = _calculateCrossAxisCount(constraints.maxWidth);

        return Scaffold(
          appBar: AppBar(title: const Text("War Fighting Functions")),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: warFightingFunctions.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.9,
                ),
                itemBuilder: (context, index) {
                  return WarFightingFunctionCard(
                    wff: warFightingFunctions[index],
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

