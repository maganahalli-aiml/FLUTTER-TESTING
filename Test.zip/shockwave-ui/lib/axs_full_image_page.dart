import 'package:flutter/material.dart';

class AxsFullImagePage extends StatelessWidget {
  const AxsFullImagePage({super.key});

  @override
  Widget build(BuildContext context) {

    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AXS Full Image'),
        backgroundColor: theme.appBarTheme.backgroundColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(
              'assets/images/axs.png',
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}