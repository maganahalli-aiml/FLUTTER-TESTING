import 'package:flutter/material.dart';
import 'package:shockwave/themes/theme_manager.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Center(
        child: ValueListenableBuilder<ThemeMode>(
          valueListenable: themeNotifier,
          builder: (context, themeMode, child) {
            final isDark = themeMode == ThemeMode.dark;
            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.wb_sunny,
                  color: isDark ? Colors.grey : Colors.orange,
                ),
                Switch(
                  value: isDark,
                  onChanged: (val) => ThemeManager.toggleTheme(val),
                ),
                Icon(
                  Icons.nightlight_round,
                  color: isDark ? Colors.blue : Colors.grey,
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
