import 'package:flutter/material.dart';
import '../models/war_fighting_models.dart';

// // final String localBase = Platform.isAndroid ? 'http://10.0.2:8000' : 'http://localhost:8000';

const List<WarFightingFunction> warFightingFunctions = [
  WarFightingFunction(
    name: 'Fires',
    icon: Icons.whatshot,
    description:
        'Fire support coordination, target acquisition, ballistic calculations, and effects assessment for lethal and non-lethal fires.',
    apps: [
      AppInfo(
        name: 'AXS App',
        icon: Icons.fireplace,
        url: 'https://10.137.6.210/fires/',
      ),
    ],
  ),
  WarFightingFunction(
    name: 'Command & Control',
    icon: Icons.bolt,
    description: 'Centralized command and control operations.',
    apps: [
      AppInfo(name: 'Command App', icon: Icons.bolt, url: '/command'),
      AppInfo(name: 'TBD', icon: Icons.bolt, url: '/TBD'),
    ],
  ),
  WarFightingFunction(
    name: 'Movement & Manuever',
    icon: Icons.whatshot,
    description:
        'Route planning, terrain analysis, and tactical movement coordination with GPS integration and obstacle avoidance algorithms.',
    apps: [AppInfo(name: 'Test', icon: Icons.fireplace, url: '/tbd')],
  ),
  WarFightingFunction(
    name: 'Intelligence',
    icon: Icons.search,
    description:
        'Multi-source intelligence fusion, threat assessment, pattern analysis, and predictive analytics for battlefield awareness.',
    apps: [AppInfo(name: 'Test', icon: Icons.fireplace, url: '/tbd')],
  ),
  WarFightingFunction(
    name: 'Protection',
    icon: Icons.shield,
    description:
        'Force protection monitoring, threat warning systems, cybersecurity dashboard, and survivability enhancement tools.',
    apps: [AppInfo(name: 'Test', icon: Icons.fireplace, url: '/tbd')],
  ),
  WarFightingFunction(
    name: 'Sustainment',
    icon: Icons.build,
    description:
        'Logistics management, supply chain tracking, personnel services, and medical support coordination for sustained operations.',
    apps: [AppInfo(name: 'Test', icon: Icons.fireplace, url: '/tbd')],
  ),
];
