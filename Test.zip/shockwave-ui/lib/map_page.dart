import 'package:flutter/material.dart';
import 'my_map_page.dart';
import 'message_side_bar.dart';

class MapPage extends StatelessWidget {
  const MapPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      body: SafeArea(
        child: Container(
          color: theme.colorScheme.background,
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    const Expanded(
                      child: Row(
                        children: [
                          Expanded(flex: 2, child: MyMapPage()),
                          Expanded(flex: 1, child: MessageSidebar()),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Top-right profile icon
              // Delete
              /*
              const Positioned(
                top: 16,
                right: 16,
                child: Icon(
                  Icons.person,
                  size: 36,
                  color: Color.fromARGB(255, 179, 0, 255),
                ),
              ),
              */
            ],
          ),
        ),
      ),
    );
  }
}
