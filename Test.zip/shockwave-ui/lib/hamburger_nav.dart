import 'package:flutter/material.dart';

class HamburgerNav extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTapTab;

  const HamburgerNav({
    super.key,
    required this.currentIndex,
    required this.onTapTab,
  });

  Widget _buildDrawerItem(BuildContext context, IconData icon, String label, int index, {bool enlargedIcon = false}) {

    final theme = Theme.of(context);
    // Use the theme's color scheme for consistent styling
    return ListTile(
      leading: Icon(
        icon,
        color: theme.iconTheme.color,
        size: enlargedIcon ? 56 : null,
      ),
      title: Text(label, style:  TextStyle(color: theme.textTheme.bodyLarge?.color)),
      selected: currentIndex == index,
      selectedTileColor: theme.listTileTheme.selectedColor,
      onTap: () => onTapTab(index),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Drawer(
      child: Container(
        color: theme.colorScheme.surface,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // Creating Profile Button in placed of the DrawerHeader
            /*
            const DrawerHeader(
              decoration: BoxDecoration(color: Color.fromARGB(255, 77, 75, 77)),
              // Changed Code:
              child: Text('Navigation', style: TextStyle(fontSize: 24, color: Color.fromARGB(255, 207, 207, 207))),
            ),
            */
            Container(
              color: Theme.of(context).colorScheme.surface,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: _buildDrawerItem(context, Icons.person, 'Profile', 7, enlargedIcon: true,),
            ),
            _buildDrawerItem(context, Icons.apps, 'Apps', 0),
            _buildDrawerItem(context, Icons.map, 'Map', 1),
            _buildDrawerItem(context, Icons.chat_bubble, 'Comms', 2),
            _buildDrawerItem(context, Icons.group, 'Command', 3),
            _buildDrawerItem(context, Icons.extension, 'Packages', 4),
            _buildDrawerItem(context, Icons.hub, 'Node Connection', 5),
            _buildDrawerItem(context, Icons.settings, 'Settings', 6),
          ],
        ),
      ),
    );
  }
}
