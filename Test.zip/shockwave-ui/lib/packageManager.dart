import 'package:flutter/material.dart';
import 'axs_full_image_page.dart';

class Package {
  final String name;
  final String description;
  final String imageUrl;
  bool installed;
  bool updateAvailable;

  Package({
    required this.name,
    required this.description,
    required this.imageUrl,
    this.installed = false,
    this.updateAvailable = false,
  });
}

class PackageManagerPage extends StatefulWidget {
  const PackageManagerPage({super.key});

  @override
  State<PackageManagerPage> createState() => _PackageManagerPageState();
}

class _PackageManagerPageState extends State<PackageManagerPage> {
  late List<Package> _allPackages;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _allPackages = [
      Package(
        name: 'ARCGIS',
        description: 'Advanced mapping and geospatial analysis tools.',
        imageUrl: 'https://img.icons8.com/color/96/000000/compass.png',
      ),
      Package(
        name: 'ElementComms',
        description: 'Enhanced communication suite for teams.',
        imageUrl: 'https://img.icons8.com/color/96/000000/chat.png',
        installed: true,
        updateAvailable: true,
      ),
      Package(
        name: 'AXS',
        description: 'Real-time fire detection and alert system.',
        imageUrl: 'https://img.icons8.com/color/96/000000/fire-element.png',
      ),
      Package(
        name: 'CommandX',
        description: 'Command and control dashboard extension.',
        imageUrl: 'https://img.icons8.com/color/96/000000/command-line.png',
      ),
      // Dummy packages for testing
      for (int i = 1; i <= 10; i++)
        Package(
          name: 'Dummy Package $i',
          description: 'This is a dummy package for testing purposes.',
          imageUrl: 'https://img.icons8.com/color/96/000000/box.png',
          installed: i % 3 == 0,
          updateAvailable: i % 4 == 0,
        ),
    ];
  }

  void _installPackage(Package pkg) {
    setState(() {
      pkg.installed = true;
    });
  }

  void _uninstallPackage(Package pkg) {
    setState(() {
      pkg.installed = false;
      pkg.updateAvailable = false;
    });
  }

  void _updatePackage(Package pkg) {
    setState(() {
      pkg.updateAvailable = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${pkg.name} updated!')),
    );
  }

  /*
  void _showPackageDetails(Package pkg) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(pkg.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.network(pkg.imageUrl, height: 80),
            const SizedBox(height: 16),
            Text(pkg.description),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close', style: TextStyle(color: Color(0xFFFFF700))),
          ),
        ],
      ),
    );
  }*/

  void _showPackageDetails(Package pkg) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(pkg.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.network(pkg.imageUrl, height: 80),
            const SizedBox(height: 16),
            Text(pkg.description),
          ],
        ),
        actions: [
          if (pkg.name == 'AXS')
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const AxsFullImagePage(),
                  ),
                );
              },
              child: Text(
                'Open',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child:  Text('Close', style: TextStyle(color: Theme.of(context).colorScheme.primary)),
          ),
        ],
      )
    );
  }

  List<Package> get _filteredPackages {
    if (_searchQuery.isEmpty) return _allPackages;
    return _allPackages
        .where((pkg) => pkg.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            pkg.description.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Package Manager', style: TextStyle(color: theme.colorScheme.onBackground)),
        backgroundColor: theme.colorScheme.background,
        iconTheme: IconThemeData(color: theme.colorScheme.onBackground),
      ),
      backgroundColor: theme.colorScheme.background,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search packages...',
                prefixIcon: Icon(Icons.search, color: theme.colorScheme.primary),
                filled: true,
                fillColor: theme.colorScheme.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              style: TextStyle(color: theme.colorScheme.onSurface),
              onChanged: (value) => setState(() => _searchQuery = value),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredPackages.length,
              itemBuilder: (context, index) {
                final pkg = _filteredPackages[index];

                return Card(
                  color: theme.colorScheme.surface,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: Image.network(pkg.imageUrl, width: 48, height: 48),
                    title: Text(pkg.name, style: TextStyle(color: theme.colorScheme.onSurface)),
                    subtitle: Text(pkg.description, style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.7))),
                    onTap: () => _showPackageDetails(pkg),
                    trailing: pkg.installed
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              ElevatedButton(
                                onPressed: null,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: theme.colorScheme.primary,
                                ),
                                child: Text('Already Installed'),
                              ),
                              if (pkg.updateAvailable) ...[
                                const SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: () => _updatePackage(pkg),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blueAccent
                                  ),
                                  child: Text('Update'),
                                ),
                              ],
                              const SizedBox(width: 8),
                              ElevatedButton(
                                onPressed: () => _uninstallPackage(pkg),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.redAccent
                                ),
                                child: Text('Uninstall'),
                              ),
                            ],
                          )
                        : ElevatedButton(
                            onPressed: () => _installPackage(pkg),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green, // Use a different color for install button),
                            ),
                            child: Text('Install'),
                          ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
