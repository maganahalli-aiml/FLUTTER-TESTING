import 'package:flutter/material.dart';

class AppInfo {
  final String name;
  final IconData icon;
  final String url;

  const AppInfo({required this.name, required this.icon, required this.url});
}

class WarFightingFunction {
  final String name;
  final IconData icon;
  final String description;
  final List<AppInfo> apps;

  const WarFightingFunction({
    required this.name,
    required this.icon,
    required this.description,
    required this.apps,
  });
}
