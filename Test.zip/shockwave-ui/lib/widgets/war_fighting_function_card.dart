import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/war_fighting_models.dart';

class WarFightingFunctionCard extends StatefulWidget {
  final WarFightingFunction wff;

  const WarFightingFunctionCard({super.key, required this.wff});

  @override
  State<WarFightingFunctionCard> createState() =>
      _WarFightingFunctionCardState();
}

class _WarFightingFunctionCardState extends State<WarFightingFunctionCard> {
  bool _isExpanded = false;
  // bool _hovering = false;

  Future<void> _launchApp(String url, String appname) async {
    final shouldLeave = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Launch $appname'),
          content: Text('Do you want to launch $appname?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Launch'),
            ),
          ],
        );
      },
    );

    if (shouldLeave == true) {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Could not launch $appname')));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(8),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => setState(() => _isExpanded = !_isExpanded),
        hoverColor: Theme.of(context).colorScheme.tertiary,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Icon(widget.wff.icon, size: 48),
              const SizedBox(height: 8),
              Text(
                widget.wff.name,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: theme.textTheme.bodyLarge?.color,
                ),                
                textAlign: TextAlign.center,
              ),
              Text(
                widget.wff.description,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: theme.textTheme.bodyMedium?.color,
                ),
              ),
              if (_isExpanded) ...[
                const Divider(height: 20, thickness: 2),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 3,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: widget.wff.apps.length,
                  itemBuilder: (context, index) {
                    final app = widget.wff.apps[index];
                    return ElevatedButton.icon(
                      onPressed: () => _launchApp(app.url, app.name),
                      icon: Icon(app.icon),
                      label: Text(app.name),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(8),
                        backgroundColor: theme.colorScheme.secondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        foregroundColor: theme.colorScheme.tertiary,
                      ),
                    );
                  },
                ),
              ],
              Align(
                alignment: Alignment.bottomRight,
                child: Icon(
                  _isExpanded ? Icons.expand_less : Icons.expand_more,
                  size: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
