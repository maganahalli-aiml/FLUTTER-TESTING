import 'package:flutter/material.dart';

class CommsPage extends StatefulWidget {
  const CommsPage({super.key});

  @override
  State<CommsPage> createState() => _CommsPageState();

}

class _CommsPageState extends State<CommsPage> {

  final TextEditingController _controller = TextEditingController();

  // Simulated Chat Rooms (in real integration, those will come
  // from Matrix room list)
  final List<String> _rooms = ['Alpha', 'Bravo', 'Command'];
  String _currentRoom = 'Alpha';

  // In-memory message storage (to be replaced with synced
  // Matrix room timelines)
  final Map<String, List<Map<String, dynamic>>> _roomMessages = {
    'Alpha': [
      {'text': 'Alpha hold in position.', 'isMe': true},
      {'text': 'Hold your position. Awaiting green light.', 'isMe': false},
    ],
    'Bravo': [
      {'text': 'Bravo teem patrolling Sector B.', 'isMe': true},
      {'text': 'Copy, maintain radio silence.', 'isMe': false},
    ],
    'Command': [
      {'text': 'All teams check in.', 'isMe': false},
    ],
  };

  // FRONT-END ONLY: Sends a message to the current chat room
  // LATER: Replace this with Matrix SDK 'sendMessage(roomId, message)'
  void _sendMessage() {

    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _roomMessages[_currentRoom]!.add({
        'text': text,
        'isMe': true,
      });
      _controller.clear();
    });

    // TODO: Integrate with matrix backend
    // matrixClient.sendMessage(roomId: _currentRoomId, message: text);

  }

  // Switch between chat rooms (simulated)
  // LATER: On room switch, fetch and sync timeline from Matrix backend
  void _switchRoom(String room) {

    setState(() {
      _currentRoom = room;
    });

    // TODO: Use Matrix SDK ot fetch timeline for this room
    // await matrixClient.syncRoomTimeline(roomId);

  }

  @override
  Widget build(BuildContext context) {
    final messages = _roomMessages[_currentRoom]!;

    return Scaffold(
      backgroundColor: const Color(0xFF1E1E2E),
      appBar: AppBar(
        title: Text('Comms - $_currentRoom'),
        backgroundColor: const Color(0xFF2A2A3D),
        actions: [
          // Room Selector
          // LATER: Replace with dynamic room list from Matrix homeserver
          PopupMenuButton<String>(
            icon: const Icon(Icons.chat_bubble_outline),
            onSelected: _switchRoom,
            color: const Color(0xFF2A2A3D),
            itemBuilder: (context) {
              return _rooms.map((room) {
                return PopupMenuItem<String>(
                  value: room,
                  child: Text(
                    room,
                    style: TextStyle(
                      color: room == _currentRoom ? Colors.yellowAccent : Colors.white,
                    ),
                  ),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Message Timeline
          // LATER: Replace this with live message stream from Matrix
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              reverse: false,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isMe = msg['isMe'] as bool;

                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isMe ? Colors.blueAccent.withOpacity(0.85) : Colors.grey[700],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      msg['text'],
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontFamily: 'monospace',  // Tactical appearance
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Message Input Section
          // LATER: Handle encryption, typing indicators, etc.
          Container(
            color: const Color(0xFF2A2A3D),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      hintStyle: const TextStyle(color: Colors.white70),
                      filled: true,
                      fillColor: const Color(0xFF3A3A4D),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    style: const TextStyle(color: Colors.white),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _sendMessage,
                  icon: const Icon(Icons.send, color: Colors.yellowAccent),
                ),
              ],
            ),
          ),
        ],
      ),

    );
  }

}
