import 'package:flutter/material.dart';
import 'dart:math';

class AnimatedLightningBackground extends StatefulWidget {
  const AnimatedLightningBackground({super.key});

  @override
  State<AnimatedLightningBackground> createState() => _AnimatedLightningBackgroundState();
}

class _AnimatedLightningBackgroundState extends State<AnimatedLightningBackground> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: _TechyGridPainter(_controller.value),
          size: MediaQuery.of(context).size,
        );
      },
    );
  }
}

class _TechyGridPainter extends CustomPainter {
  final double progress;
  static final Random _rand = Random(42);

  _TechyGridPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final Paint gridPaint = Paint()
      ..color = const Color(0xFFFFF700).withOpacity(0.08)
      ..strokeWidth = 2;
    final Paint glowPaint = Paint()
      ..color = const Color(0xFFFFF700).withOpacity(0.18)
      ..strokeWidth = 6
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    final Paint nodePaint = Paint()
      ..color = const Color(0xFFFFF700).withOpacity(0.18)
      ..style = PaintingStyle.fill;
    final Paint nodeGlowPaint = Paint()
      ..color = const Color(0xFFFFF700).withOpacity(0.10)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);

    // Draw diagonal grid lines
    double spacing = 60;
    for (double x = -size.height; x < size.width + size.height; x += spacing) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x - size.height, size.height),
        gridPaint,
      );
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        gridPaint,
      );
    }

    // Draw glowing nodes at grid intersections
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        if ((x ~/ spacing + y ~/ spacing) % 2 == 0) {
          canvas.drawCircle(Offset(x, y), 7, nodeGlowPaint);
          canvas.drawCircle(Offset(x, y), 2.5, nodePaint);
        }
      }
    }

    // Animate a few particles moving along the grid
    int particles = 8;
    for (int i = 0; i < particles; i++) {
      double t = (progress + i / particles) % 1.0;
      double px = lerpDouble(-40, size.width + 40, t)!;
      double py = size.height * (0.2 + 0.6 * (i / particles));
      // Move diagonally
      px += 30 * sin(progress * 2 * pi + i);
      py += 30 * cos(progress * 2 * pi + i * 1.3);
      canvas.drawCircle(
        Offset(px, py),
        5,
        Paint()
          ..color = const Color(0xFFFFF700).withOpacity(0.25)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        Offset(px, py),
        2.2,
        Paint()..color = const Color(0xFFFFF700).withOpacity(0.8),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _TechyGridPainter oldDelegate) => true;
}

double? lerpDouble(num a, num b, double t) {
  return a * (1.0 - t) + b * t;
}
