import 'package:flutter/material.dart';

class NodeConnectionPage extends StatefulWidget {
  const NodeConnectionPage({super.key});

  @override
  State<NodeConnectionPage> createState() => _NodeConnectionPageState();
}

class _NodeConnectionPageState extends State<NodeConnectionPage> {
  bool _connected = false;

  // Example node info
  final Map<String, String> _nodeInfo = {
    'Node ID': 'NODE-1234',
    'Status': 'Active',
    'Location': 'HQ - Floor 2',
    'Last Sync': '2 min ago',
  };

  void _openCamera() {
    // Placeholder for camera logic
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Camera'),
        content: const Text('Camera would open here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Node Connection', style: TextStyle(color: theme.colorScheme.onBackground)),
        backgroundColor: theme.colorScheme.background,
        centerTitle: true,
        iconTheme: IconThemeData(color: theme.colorScheme.onBackground),
      ),
      backgroundColor: theme.colorScheme.background,
      body: Center(
        child: _connected
            ? Card(
                color: theme.colorScheme.surface,
                margin: const EdgeInsets.all(24),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Connected to Node', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: theme.colorScheme.primary)),
                      const SizedBox(height: 16),
                      ..._nodeInfo.entries.map((e) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Text('${e.key}: ', style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.7), fontWeight: FontWeight.bold)),
                                Text(e.value, style: TextStyle(color: theme.colorScheme.onSurface)),
                              ],
                            ),
                          )),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: () => setState(() => _connected = false),
                        style: ElevatedButton.styleFrom(backgroundColor: theme.colorScheme.error, foregroundColor: theme.colorScheme.onError),
                        child: Text('Disconnect', style: TextStyle(color: theme.colorScheme.onError)),
                      ),
                    ],
                  ),
                ),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.link_off, size: 60, color: theme.colorScheme.onSurface.withOpacity(0.38)),
                  const SizedBox(height: 24),
                  Text('No node connected', style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.7), fontSize: 18)),
                  const SizedBox(height: 32),
                  ElevatedButton.icon(
                    onPressed: _openCamera,
                    icon: Icon(Icons.camera_alt, color: theme.colorScheme.onPrimary),
                    label: Text('Scan to Connect', style: TextStyle(color: theme.colorScheme.onPrimary)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
                      textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
