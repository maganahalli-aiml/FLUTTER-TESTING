package com.example.shockwave

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
